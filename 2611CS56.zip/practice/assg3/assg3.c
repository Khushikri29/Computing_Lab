#include <stdio.h>
#include <math.h>

extern void myinit(int numDisk);
extern void mymove(int disk, int peg1, int peg2);
extern void mydisplay();
extern void myreset();


/* 3-Peg Tower of Hanoi */

void toh3(int i, int j, int a, int b, int c)
{
    if(i > j)
        return;

    if(i == j)
    {
        mymove(i, a, c);
        return;
    }

    toh3(i, j-1, a, c, b);

    mymove(j, a, c);

    toh3(i, j-1, b, a, c);
}


/* Function 1 */

void toh4A(int i, int j, int a, int b, int c, int d)
{
    int m, k;

    if(i > j)
        return;

    if(i == j)
    {
        mymove(i, a, d);
        return;
    }

    m = j - i + 1;

    k = m / 2;

    toh4A(i, j-k, a, d, c, b);

    toh3(j-k+1, j, a, b, c);

    toh4A(i, j-k, b, a, c, d);
}


/* Function 2 */

void toh4B(int i, int j, int a, int b, int c, int d, int k)
{
    int m;

    if(i > j)
        return;

    m = j - i + 1;

    if(m <= k)
    {
        toh3(i, j, a, b, d);
        return;
    }

    toh4B(i, j-k, a, d, c, b, k);

    toh3(j-k+1, j, a, b, d);

    toh4B(i, j-k, b, a, c, d, k);
}


/* Function 3 */

void toh4C(int i, int j, int a, int b, int c, int d)
{
    int m, k;

    if(i > j)
        return;

    if(i == j)
    {
        mymove(i, a, d);
        return;
    }

    m = j - i + 1;

    k = round(sqrt(2 * m));

    toh4C(i, j-k, a, d, c, b);

    toh3(j-k+1, j, a, b, c);

    toh4C(i, j-k, b, a, c, d);
}


/* Main */

int main()
{
    int n;
    int k;

    printf("Enter number of disks: ");
    scanf("%d", &n);

    myinit(n);

    mydisplay();

    toh4A(1, n, 0, 1, 2, 3);

    mydisplay();


    myreset();

    mydisplay();

    k = sqrt(n);

    toh4B(1, n, 0, 1, 2, 3, k);

    mydisplay();


    myreset();

    mydisplay();

    toh4C(1, n, 0, 1, 2, 3);

    mydisplay();

    return 0;
}

/*gcc assg03.c tohfunc.o -lm
./a.out
gcc assg03.c tohfunc.o -lm -o assg03
./assg03
*/