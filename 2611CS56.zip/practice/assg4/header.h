#ifndef HEADER_H
#define HEADER_H

#define MAX 100

typedef enum
{
    BLOCK,
    DECISION,
    UNCOND
} Type;

typedef struct
{
    char name[50];
    Type type;

    char code[2000];

    char condition[500];

    char trueBlock[50];
    char falseBlock[50];

    char gotoBlock[50];

} Node;

extern Node nodes[MAX];
extern int nodeCount;

void addBlock(char *name, char *code);
void addDecision(char *name, char *condition,
                 char *trueBlock, char *falseBlock);
void addUncond(char *name, char *gotoBlock);

void generateC();

#endif