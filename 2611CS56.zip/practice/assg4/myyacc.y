%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"

int yylex();
void yyerror(char *);

%}

%union
{
    char *str;
}

%token SYSTEM PROCESS PROCESSDEF START END
%token BLOCK_KW DECISION_KW
%token IF THEN ELSE
%token UNCONDDEC GOTO

%token <str> ID
%token <str> NUMBER

%token EQ GE LE NE

%%


program:
      SYSTEM ID ';'
      PROCESS process_list ';'
      process_def
      ;


process_list:
      ID
      | process_list ',' ID
      ;


process_def:
      PROCESSDEF ID START statements END
      ;


statements:
      statements statement
      | statement
      ;


statement:
      block
      | decision
      | uncond
      ;


block:
      BLOCK_KW ID START code END
      {
          addBlock($2, $4);
      }
      ;


decision:
      DECISION_KW ID
      IF condition
      THEN GOTO ID
      ELSE GOTO ID
      {
          addDecision($2, $4, $7, $10);
      }
      ;


uncond:
      UNCONDDEC ID GOTO ID
      {
          addUncond($2, $4);
      }
      ;


condition:
      ID '<' NUMBER
      {
          char temp[200];

          sprintf(temp, "%s < %s", $1, $3);

          $$ = strdup(temp);
      }

      | ID '>' NUMBER
      {
          char temp[200];

          sprintf(temp, "%s > %s", $1, $3);

          $$ = strdup(temp);
      }

      | ID EQ NUMBER
      {
          char temp[200];

          sprintf(temp, "%s == %s", $1, $3);

          $$ = strdup(temp);
      }
      ;


code:
      ID
      {
          $$ = strdup($1);
      }
      ;


%%


void yyerror(char *s)
{
    printf("Syntax Error: %s\n", s);
}