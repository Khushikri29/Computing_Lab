#include <stdio.h>
#include <string.h>
#include "header.h"

Node nodes[MAX];
int nodeCount = 0;


void addBlock(char *name, char *code)
{
    strcpy(nodes[nodeCount].name, name);

    nodes[nodeCount].type = BLOCK;

    strcpy(nodes[nodeCount].code, code);

    nodeCount++;
}


void addDecision(char *name, char *condition,
                 char *trueBlock, char *falseBlock)
{
    strcpy(nodes[nodeCount].name, name);

    nodes[nodeCount].type = DECISION;

    strcpy(nodes[nodeCount].condition, condition);

    strcpy(nodes[nodeCount].trueBlock, trueBlock);

    strcpy(nodes[nodeCount].falseBlock, falseBlock);

    nodeCount++;
}


void addUncond(char *name, char *gotoBlock)
{
    strcpy(nodes[nodeCount].name, name);

    nodes[nodeCount].type = UNCOND;

    strcpy(nodes[nodeCount].gotoBlock, gotoBlock);

    nodeCount++;
}


void generateC()
{
    int i;

    printf("#include <stdio.h>\n\n");

    printf("int main()\n");
    printf("{\n");

    /*
       Start from first node
    */

    if(nodeCount > 0)
        printf("    goto %s;\n", nodes[0].name);


    for(i = 0; i < nodeCount; i++)
    {
        printf("\n%s:\n", nodes[i].name);

        if(nodes[i].type == BLOCK)
        {
            printf("%s\n", nodes[i].code);
        }

        else if(nodes[i].type == DECISION)
        {
            printf("    if(%s)\n", nodes[i].condition);

            printf("        goto %s;\n",
                   nodes[i].trueBlock);

            if(strlen(nodes[i].falseBlock) > 0)
            {
                printf("    else\n");
                printf("        goto %s;\n",
                       nodes[i].falseBlock);
            }
        }

        else if(nodes[i].type == UNCOND)
        {
            printf("    goto %s;\n",
                   nodes[i].gotoBlock);
        }
    }

    printf("\n    return 0;\n");
    printf("}\n");
}


int main()
{
    yyparse();

    generateC();

    return 0;
}