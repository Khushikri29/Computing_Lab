#include <stdio.h>
#include <string.h>

int min(int a, int b)
{
    if(a < b)
        return a;
    return b;
}

int main()
{
    char a[100], b[100];
    int dp[100][100];
    int i, j;
    int m, n;

    printf("Enter first string: ");
    scanf("%s", a);

    printf("Enter second string: ");
    scanf("%s", b);

    m = strlen(a);
    n = strlen(b);

    for(i = 0; i <= m; i++)
        dp[i][0] = i;

    for(j = 0; j <= n; j++)
        dp[0][j] = j;

    for(i = 1; i <= m; i++)
    {
        for(j = 1; j <= n; j++)
        {
            if(a[i-1] == b[j-1])
            {
                dp[i][j] = dp[i-1][j-1];
            }
            else
            {
                dp[i][j] = 1 + min(
                    min(dp[i-1][j], dp[i][j-1]),
                    dp[i-1][j-1]
                );
            }
        }
    }

    printf("Edit Distance = %d\n", dp[m][n]);

    return 0;
}