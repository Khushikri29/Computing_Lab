#include <stdio.h>

int main()
{
    int n;
    int a[1000];
    int count[1000] = {0};

    int i, j;
    int max;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter elements: ");

    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);

    max = a[0];

    for(i = 1; i < n; i++)
    {
        if(a[i] > max)
            max = a[i];
    }

    for(i = 0; i < n; i++)
        count[a[i]]++;

    printf("Sorted array: ");

    for(i = 0; i <= max; i++)
    {
        for(j = 0; j < count[i]; j++)
        {
            printf("%d ", i);
        }
    }

    printf("\n");

    return 0;
}