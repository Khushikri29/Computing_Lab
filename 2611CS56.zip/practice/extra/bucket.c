#include <stdio.h>

void bucketSort(float a[], int n)
{
    float bucket[10][100];
    int count[10] = {0};

    int i, j, k;
    int b;
    float temp;

    /* Put elements into buckets */

    for(i = 0; i < n; i++)
    {
        b = (int)(a[i] * 10);

        bucket[b][count[b]] = a[i];

        count[b]++;
    }


    /* Sort each bucket */

    for(i = 0; i < 10; i++)
    {
        for(j = 0; j < count[i] - 1; j++)
        {
            for(k = 0; k < count[i] - j - 1; k++)
            {
                if(bucket[i][k] > bucket[i][k + 1])
                {
                    temp = bucket[i][k];

                    bucket[i][k] = bucket[i][k + 1];

                    bucket[i][k + 1] = temp;
                }
            }
        }
    }


    /* Combine buckets */

    k = 0;

    for(i = 0; i < 10; i++)
    {
        for(j = 0; j < count[i]; j++)
        {
            a[k] = bucket[i][j];
            k++;
        }
    }
}


int main()
{
    float a[100];

    int n;
    int i;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter numbers between 0 and 1:\n");

    for(i = 0; i < n; i++)
        scanf("%f", &a[i]);

    bucketSort(a, n);

    printf("Sorted array:\n");

    for(i = 0; i < n; i++)
        printf("%.2f ", a[i]);

    printf("\n");

    return 0;
}