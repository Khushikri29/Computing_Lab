#include <stdio.h>

#define INF 99999

int main()
{
    int n, amount;
    int coin[100];
    int dp[1000];
    int i, j;

    printf("Enter number of coins: ");
    scanf("%d", &n);

    printf("Enter coins: ");
    for(i = 0; i < n; i++)
        scanf("%d", &coin[i]);

    printf("Enter amount: ");
    scanf("%d", &amount);

    dp[0] = 0;

    for(i = 1; i <= amount; i++)
        dp[i] = INF;

    for(i = 1; i <= amount; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(coin[j] <= i)
            {
                if(dp[i - coin[j]] + 1 < dp[i])
                    dp[i] = dp[i - coin[j]] + 1;
            }
        }
    }

    if(dp[amount] == INF)
        printf("Not possible\n");
    else
        printf("Minimum coins = %d\n", dp[amount]);

    return 0;
}
//number of ways
#include <stdio.h>

int main()
{
    int n, amount;
    int coin[100];
    long long int dp[1000];
    int i, j;

    printf("Enter number of coins: ");
    scanf("%d", &n);

    printf("Enter coins: ");
    for(i = 0; i < n; i++)
        scanf("%d", &coin[i]);

    printf("Enter amount: ");
    scanf("%d", &amount);

    for(i = 0; i <= amount; i++)
        dp[i] = 0;

    dp[0] = 1;

    for(i = 0; i < n; i++)
    {
        for(j = coin[i]; j <= amount; j++)
        {
            dp[j] = dp[j] + dp[j - coin[i]];
        }
    }

    printf("Number of ways = %lld\n", dp[amount]);

    return 0;
}