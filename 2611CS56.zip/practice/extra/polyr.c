#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846

typedef struct
{
    double real;
    double imag;
} Complex;


Complex add(Complex a, Complex b)
{
    Complex c;

    c.real = a.real + b.real;
    c.imag = a.imag + b.imag;

    return c;
}


Complex subtract(Complex a, Complex b)
{
    Complex c;

    c.real = a.real - b.real;
    c.imag = a.imag - b.imag;

    return c;
}


Complex multiply(Complex a, Complex b)
{
    Complex c;

    c.real = a.real * b.real - a.imag * b.imag;
    c.imag = a.real * b.imag + a.imag * b.real;

    return c;
}


void FFT(Complex a[], int n)
{
    int i;

    Complex even[100], odd[100];
    Complex E[100], O[100];

    if(n == 1)
        return;

    for(i = 0; i < n/2; i++)
    {
        even[i] = a[2*i];
        odd[i] = a[2*i+1];
    }

    FFT(even, n/2);
    FFT(odd, n/2);

    for(i = 0; i < n/2; i++)
    {
        double angle = -2 * PI * i / n;

        Complex W;

        W.real = cos(angle);
        W.imag = sin(angle);

        E[i] = even[i];
        O[i] = multiply(W, odd[i]);

        a[i] = add(E[i], O[i]);

        a[i+n/2] = subtract(E[i], O[i]);
    }
}


int main()
{
    Complex a[100];
    int n, i;

    printf("Enter size (power of 2): ");
    scanf("%d", &n);

    printf("Enter values:\n");

    for(i = 0; i < n; i++)
    {
        scanf("%lf", &a[i].real);
        a[i].imag = 0;
    }

    FFT(a, n);

    printf("\nFFT:\n");

    for(i = 0; i < n; i++)
    {
        printf("%.2f + %.2fi\n",
               a[i].real,
               a[i].imag);
    }

    return 0;
}