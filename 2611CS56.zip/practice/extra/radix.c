#include <stdio.h>

int getMax(int a[], int n)
{
    int max = a[0];
    int i;

    for(i = 1; i < n; i++)
    {
        if(a[i] > max)
            max = a[i];
    }

    return max;
}

void countingSort(int a[], int n, int place)
{
    int output[100];
    int count[10] = {0};

    int i;
    int digit;

    /* Count digits */

    for(i = 0; i < n; i++)
    {
        digit = (a[i] / place) % 10;
        count[digit]++;
    }

    /* Prefix sum */

    for(i = 1; i < 10; i++)
    {
        count[i] = count[i] + count[i - 1];
    }

    /* Make output array */

    for(i = n - 1; i >= 0; i--)
    {
        digit = (a[i] / place) % 10;

        output[count[digit] - 1] = a[i];

        count[digit]--;
    }

    /* Copy back */

    for(i = 0; i < n; i++)
        a[i] = output[i];
}


void radixSort(int a[], int n)
{
    int max;
    int place;

    max = getMax(a, n);

    for(place = 1; max / place > 0; place = place * 10)
    {
        countingSort(a, n, place);
    }
}


int main()
{
    int a[100];
    int n;
    int i;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter elements:\n");

    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);

    radixSort(a, n);

    printf("Sorted array:\n");

    for(i = 0; i < n; i++)
        printf("%d ", a[i]);

    printf("\n");

    return 0;
}