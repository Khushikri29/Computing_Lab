#include <stdio.h>

int max(int a, int b)
{
    if(a > b)
        return a;
    return b;
}

int main()
{
    int n, capacity;
    int weight[100], value[100];
    int dp[100][100];
    int i, w;

    printf("Enter number of items: ");
    scanf("%d", &n);

    printf("Enter weights: ");
    for(i = 0; i < n; i++)
        scanf("%d", &weight[i]);

    printf("Enter values: ");
    for(i = 0; i < n; i++)
        scanf("%d", &value[i]);

    printf("Enter capacity: ");
    scanf("%d", &capacity);

    for(w = 0; w <= capacity; w++)
        dp[0][w] = 0;

    for(i = 1; i <= n; i++)
    {
        for(w = 0; w <= capacity; w++)
        {
            if(weight[i-1] <= w)
            {
                dp[i][w] = max(
                    dp[i-1][w],
                    value[i-1] + dp[i-1][w-weight[i-1]]
                );
            }
            else
            {
                dp[i][w] = dp[i-1][w];
            }
        }
    }

    printf("Maximum value = %d\n", dp[n][capacity]);

    return 0;
}