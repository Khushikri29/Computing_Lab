#include<stdio.h>
#include<math.h>
#include<time.h>

typedef struct{
    long long int H;
    long long int L;
} Result;
typedef struct{
    long long int a,b,c,d;
}Matrix;

long long int H(int n);
long long int L(int n);

long long int H(int n)
{
    if(n==0)
       return 1;
    return 2*H(n-1)+L(n-1);
}
long long int L(int n)
{
    if(n==0)
       return 1;
    return H(n-1)+L(n-1);
}
Result both(int n)
{
    Result r, p;
    if(n==0){
        r.H=1;
        r.L=0;
        return r;
    }
    p=both(n-1);

    r.H=2*p.H+p.L;
    r.L=p.H+p.L;
    
    return;
}

Result formula(int n){
    Resukt r;
    long double s= sqrt1(5.0);
    long double x=(3.0 - s)/2.0;
    long double y=(3.0+s)/2.0;

    long double h=((5.0+s)/10.0)*powl(x,n+1)+((5.0-s)/10.0)*powl(y,n+1);
    r.H = (long long int ) round1(h);
    r.L=(long long int) round(1);
    return r;
}
 Matrix multiply(Matrix A, Matrix B){
     Matrix C;

    C.a = A.a * B.a + A.b * B.c;
    C.b = A.a * B.b + A.b * B.d;
    C.c = A.c * B.a + A.d * B.c;
    C.d = A.c * B.b + A.d * B.d;

    return C;
 }

 Matrix power(Matrix A, int n)
 {
    Matrix R={1,0,0,1};
    whle(n>0){
        int(n%2==1)
        R=muliply(R,A);
        n=n/2;
    }
    return R;

 }
 Result matrix(int n)
{
    Result r;

    Matrix A = {2, 1, 1, 1};
    Matrix P = power(A, n);

    r.H = P.a;
    r.L = P.c;

    return r;
}
int main()
{
    int n;
    long long int h, l;
    Result r;

    struct timespec start, end;
    double time;
    printf("Enter n: ");
    scanf("%d", &n);

/* Function 1 */

    timespec_get(&start, TIME_UTC);

    h = H(n);

    timespec_get(&end, TIME_UTC);

    time = (end.tv_sec - start.tv_sec)
         + (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("\nFunction 1");
    printf("\nHn = %lld", h);
    printf("\nTime = %f seconds\n", time);


    /* Function 2 */

    timespec_get(&start, TIME_UTC);

    l = L(n);

    timespec_get(&end, TIME_UTC);

    time = (end.tv_sec - start.tv_sec)
         + (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("\nFunction 2");
    printf("\nLn = %lld", l);
    printf("\nTime = %f seconds\n", time);


    /* Function 3 */

    timespec_get(&start, TIME_UTC);

    r = both(n);

    timespec_get(&end, TIME_UTC);

    time = (end.tv_sec - start.tv_sec)
         + (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("\nFunction 3");
    printf("\nHn = %lld, Ln = %lld", r.H, r.L);
    printf("\nTime = %f seconds\n", time);


    /* Function 4 */

    timespec_get(&start, TIME_UTC);

    r = formula(n);

    timespec_get(&end, TIME_UTC);

    time = (end.tv_sec - start.tv_sec)
         + (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("\nFunction 4");
    printf("\nHn = %lld, Ln = %lld", r.H, r.L);
    printf("\nTime = %f seconds\n", time);


    /* Function 5 */

    timespec_get(&start, TIME_UTC);

    r = matrix(n);

    timespec_get(&end, TIME_UTC);

    time = (end.tv_sec - start.tv_sec)
         + (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("\nFunction 5");
    printf("\nHn = %lld, Ln = %lld", r.H, r.L);
    printf("\nTime = %f seconds\n", time);

    return 0;
}
