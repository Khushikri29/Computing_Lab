#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int n, i;

    FILE *f;

    printf("Enter n: ");
    scanf("%d", &n);

    f = fopen("input.txt", "w");

    if (f == NULL)
    {
        printf("File error\n");
        return 1;
    }

    srand(time(NULL));

    for (i = 0; i < n; i++)
    {
        fprintf(f, "%d\n", rand());
    }

    fclose(f);

    printf("Input file created successfully.\n");

    return 0;
}
/*gcc generate.c -o generate
./generate
cat input.txt
gcc assg02.c -o assg02
./assg02 input.txt bubble
*/