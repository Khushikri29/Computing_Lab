#include <stdio.h>
#include <stdlib.h>
#include <time.h>


/* ---------------- BUBBLE SORT ---------------- */

long long int bubble(int a[], int n)
{
    int i, j, temp;
    long long int count = 0;

    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            count++;

            if (a[j] > a[j + 1])
            {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    return count;
}


/* ---------------- MERGE SORT ---------------- */

long long int merge(int a[], int left, int mid, int right)
{
    int i, j, k;
    long long int count = 0;

    int n1 = mid - left + 1;
    int n2 = right - mid;

    int L[n1], R[n2];

    for (i = 0; i < n1; i++)
        L[i] = a[left + i];

    for (j = 0; j < n2; j++)
        R[j] = a[mid + 1 + j];

    i = 0;
    j = 0;
    k = left;

    while (i < n1 && j < n2)
    {
        count++;

        if (L[i] <= R[j])
        {
            a[k] = L[i];
            i++;
        }
        else
        {
            a[k] = R[j];
            j++;
        }

        k++;
    }

    while (i < n1)
    {
        a[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        a[k] = R[j];
        j++;
        k++;
    }

    return count;
}


long long int mergeSort(int a[], int left, int right)
{
    int mid;
    long long int count = 0;

    if (left < right)
    {
        mid = (left + right) / 2;

        count += mergeSort(a, left, mid);
        count += mergeSort(a, mid + 1, right);

        count += merge(a, left, mid, right);
    }

    return count;
}


/* ---------------- QUICK SORT 1 ---------------- */
/* Random pivot */

long long int partition1(int a[], int low, int high)
{
    int pivotIndex, pivot;
    int i, j, temp;
    long long int count = 0;

    pivotIndex = low + rand() % (high - low + 1);

    temp = a[pivotIndex];
    a[pivotIndex] = a[high];
    a[high] = temp;

    pivot = a[high];

    i = low - 1;

    for (j = low; j < high; j++)
    {
        count++;

        if (a[j] < pivot)
        {
            i++;

            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
    }

    temp = a[i + 1];
    a[i + 1] = a[high];
    a[high] = temp;

    return i + 1;
}


long long int quick1(int a[], int low, int high)
{
    long long int count = 0;
    int p;

    if (low < high)
    {
        p = partition1(a, low, high);

        count += high - low;

        count += quick1(a, low, p - 1);
        count += quick1(a, p + 1, high);
    }

    return count;
}


/* ---------------- QUICK SORT 3 ---------------- */
/* Median of 3 random elements */

int median3(int x, int y, int z)
{
    if ((x <= y && y <= z) || (z <= y && y <= x))
        return y;

    if ((y <= x && x <= z) || (z <= x && x <= y))
        return x;

    return z;
}


long long int partition3(int a[], int low, int high)
{
    int p1, p2, p3;
    int pivot;
    int i, j, temp;
    long long int count = 0;

    p1 = low + rand() % (high - low + 1);
    p2 = low + rand() % (high - low + 1);
    p3 = low + rand() % (high - low + 1);

    pivot = median3(a[p1], a[p2], a[p3]);

    /* Find pivot and move it to end */

    for (i = low; i <= high; i++)
    {
        if (a[i] == pivot)
        {
            temp = a[i];
            a[i] = a[high];
            a[high] = temp;
            break;
        }
    }

    i = low - 1;

    for (j = low; j < high; j++)
    {
        count++;

        if (a[j] < pivot)
        {
            i++;

            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
    }

    temp = a[i + 1];
    a[i + 1] = a[high];
    a[high] = temp;

    return i + 1;
}


long long int quick3(int a[], int low, int high)
{
    long long int count = 0;
    int p;

    if (low < high)
    {
        p = partition3(a, low, high);

        count += high - low;

        count += quick3(a, low, p - 1);
        count += quick3(a, p + 1, high);
    }

    return count;
}


/* ---------------- COPY ARRAY ---------------- */

void copyArray(int a[], int b[], int n)
{
    int i;

    for (i = 0; i < n; i++)
        b[i] = a[i];
}


/* ---------------- MAIN ---------------- */

int main(int argc, char *argv[])
{
    FILE *fp;

    int n, i;
    int *original;
    int *a;

    long long int comparisons;

    struct timespec start, end;

    double time_taken;


    if (argc < 3)
    {
        printf("Usage: %s input.txt bubble|merge|quick1|quick3\n", argv[0]);
        return 1;
    }


    /* Open input file */

    fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        printf("Cannot open file.\n");
        return 1;
    }


    /* Count numbers */

    n = 0;

    int x;

    while (fscanf(fp, "%d", &x) == 1)
        n++;

    rewind(fp);


    /* Create arrays */

    original = malloc(n * sizeof(int));
    a = malloc(n * sizeof(int));


    /* Read numbers */

    for (i = 0; i < n; i++)
        fscanf(fp, "%d", &original[i]);

    fclose(fp);


    srand(time(NULL));


    /* ---------------- BUBBLE ---------------- */

    if (strcmp(argv[2], "bubble") == 0)
    {
        copyArray(original, a, n);

        timespec_get(&start, TIME_UTC);

        comparisons = bubble(a, n);

        timespec_get(&end, TIME_UTC);

        time_taken =
            (end.tv_sec - start.tv_sec)
            +
            (end.tv_nsec - start.tv_nsec) / 1000000000.0;

        printf("Bubble Sort\n");
        printf("N = %d\n", n);
        printf("Comparisons = %lld\n", comparisons);
        printf("Time = %f seconds\n", time_taken);
    }


    /* ---------------- MERGE ---------------- */

    else if (strcmp(argv[2], "merge") == 0)
    {
        copyArray(original, a, n);

        timespec_get(&start, TIME_UTC);

        comparisons = mergeSort(a, 0, n - 1);

        timespec_get(&end, TIME_UTC);

        time_taken =
            (end.tv_sec - start.tv_sec)
            +
            (end.tv_nsec - start.tv_nsec) / 1000000000.0;

        printf("Merge Sort\n");
        printf("N = %d\n", n);
        printf("Comparisons = %lld\n", comparisons);
        printf("Time = %f seconds\n", time_taken);
    }


    /* ---------------- QUICK1 ---------------- */

    else if (strcmp(argv[2], "quick1") == 0)
    {
        copyArray(original, a, n);

        timespec_get(&start, TIME_UTC);

        comparisons = quick1(a, 0, n - 1);

        timespec_get(&end, TIME_UTC);

        time_taken =
            (end.tv_sec - start.tv_sec)
            +
            (end.tv_nsec - start.tv_nsec) / 1000000000.0;

        printf("Quick Sort Random Pivot\n");
        printf("N = %d\n", n);
        printf("Comparisons = %lld\n", comparisons);
        printf("Time = %f seconds\n", time_taken);
    }


    /* ---------------- QUICK3 ---------------- */

    else if (strcmp(argv[2], "quick3") == 0)
    {
        copyArray(original, a, n);

        timespec_get(&start, TIME_UTC);

        comparisons = quick3(a, 0, n - 1);

        timespec_get(&end, TIME_UTC);

        time_taken =
            (end.tv_sec - start.tv_sec)
            +
            (end.tv_nsec - start.tv_nsec) / 1000000000.0;

        printf("Quick Sort Median of 3\n");
        printf("N = %d\n", n);
        printf("Comparisons = %lld\n", comparisons);
        printf("Time = %f seconds\n", time_taken);
    }


    else
    {
        printf("Invalid sorting option.\n");
        printf("Use: bubble, merge, quick1 or quick3\n");
    }


    free(original);
    free(a);

    return 0;
}