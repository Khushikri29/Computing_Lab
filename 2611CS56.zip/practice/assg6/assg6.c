#include <stdio.h>

#define MAX 50

int k, n;
int student[MAX][MAX];

int color[MAX];

int isSafe(int subject, int day)
{
    int s, j;

    for (s = 0; s < k; s++)
    {
        if (student[s][subject] == 1)
        {
            for (j = 0; j < n; j++)
            {
                if (student[s][j] == 1 && color[j] == day)
                {
                    return 0;
                }
            }
        }
    }

    return 1;
}


int schedule(int subject, int days)
{
    int day;

    if (subject == n)
        return 1;

    for (day = 1; day <= days; day++)
    {
        if (isSafe(subject, day))
        {
            color[subject] = day;

            if (schedule(subject + 1, days))
                return 1;

            color[subject] = 0;
        }
    }

    return 0;
}


int canSchedule(int days)
{
    int i;

    for (i = 0; i < n; i++)
        color[i] = 0;

    return schedule(0, days);
}


int main()
{
    int i, j;
    int m;
    int minDays;


    printf("Enter number of students: ");
    scanf("%d", &k);

    printf("Enter number of subjects: ");
    scanf("%d", &n);


    printf("\nEnter student-subject matrix:\n");

    for (i = 0; i < k; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &student[i][j]);
        }
    }


    printf("\nEnter number of days m: ");
    scanf("%d", &m);


    /* Question 1 */

    if (canSchedule(m))
        printf("\nIt is POSSIBLE to schedule exams in %d days.\n", m);
    else
        printf("\nIt is NOT POSSIBLE to schedule exams in %d days.\n", m);


    /* Question 2 */

    minDays = 1;

    while (!canSchedule(minDays))
    {
        minDays++;
    }

    printf("Minimum number of days = %d\n", minDays);


    return 0;
}
/*
assg06.c
gcc assg06.c -o assg06
./assg06
*/
