#include <stdio.h>

#define MAX 100
#define COLORS 5

long long int dp[MAX][MAX][6];

int main()
{
    int n;
    int R[6][6];
    int a[MAX];

    int i, j, k;
    int x, y, z;
    int length;


    /* Input sequence length */

    printf("Enter number of colors in sequence: ");
    scanf("%d", &n);


    /* Enter mixing matrix */

    printf("Enter 5 x 5 mixing matrix:\n");

    for(i = 1; i <= 5; i++)
    {
        for(j = 1; j <= 5; j++)
        {
            scanf("%d", &R[i][j]);
        }
    }


    /* Enter sequence */

    printf("Enter sequence:\n");

    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }


    /* Base case */

    for(i = 0; i < n; i++)
    {
        dp[i][i][a[i]] = 1;
    }


    /* DP */

    for(length = 2; length <= n; length++)
    {
        for(i = 0; i + length - 1 < n; i++)
        {
            j = i + length - 1;

            for(k = i; k < j; k++)
            {
                for(x = 1; x <= 5; x++)
                {
                    for(y = 1; y <= 5; y++)
                    {
                        if(dp[i][k][x] != 0 &&
                           dp[k+1][j][y] != 0)
                        {
                            z = R[x][y];

                            dp[i][j][z] +=
                                dp[i][k][x] *
                                dp[k+1][j][y];
                        }
                    }
                }
            }
        }
    }


    /* Print answer */

    printf("\nRESULT:\n");

    for(i = 1; i <= 5; i++)
    {
        if(dp[0][n-1][i] > 0)
        {
            printf("Color %d : possible\n", i);
            printf("Number of ways = %lld\n",
                   dp[0][n-1][i]);
        }
        else
        {
            printf("Color %d : not-possible\n", i);
            printf("Number of ways = 0\n");
        }
    }

    return 0;
}
/*assg05.c
gcc assg05.c -o assg05
./assg05
*/