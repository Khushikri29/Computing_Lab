#include "header.h"

#include <stdio.h>
#include <stdlib.h>

extern FILE *yyin;


int main(int argc, char *argv[])
{
    int result;


    if (argc != 3) {

        fprintf(
            stderr,
            "Usage: %s <ciitp-input-file> <output-c-file>\n",
            argv[0]
        );

        return 1;
    }


    yyin = fopen(argv[1], "r");

    if (!yyin) {

        perror("Could not open input file");

        return 1;
    }


    outfp = fopen(argv[2], "w");

    if (!outfp) {

        perror("Could not open output file");

        fclose(yyin);

        return 1;
    }


    result = yyparse();


    fclose(yyin);
    fclose(outfp);


    if (result == 0 && !semantic_error) {

        printf(
            "Success! C code generated in %s\n",
            argv[2]
        );

        return 0;
    }


    

    remove(argv[2]);


    printf("Compilation failed.\n");


    return 1;
}