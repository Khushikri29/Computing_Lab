%{
#include "header.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Node nodes[MAX_NODES];

int node_count = 0;

int semantic_error = 0;

static char *current_else_target = NULL;




static Node *find_node(const char *id)
{
    int i;

    for (i = 0; i < node_count; i++) {

        if (strcmp(nodes[i].id, id) == 0)
            return &nodes[i];
    }

    return NULL;
}




static void add_node(
    const char *id,
    NodeType type,
    const char *code,
    const char *condition,
    const char *true_target,
    const char *false_target)
{
    Node *n;

    if (node_count >= MAX_NODES) {

        fprintf(stderr,
                "Error: too many blocks/decisions\n");

        semantic_error = 1;

        return;
    }


    /* duplicate identifier check */

    if (find_node(id) != NULL) {

        fprintf(stderr,
                "Error: duplicate identifier '%s'\n",
                id);

        semantic_error = 1;

        return;
    }


    n = &nodes[node_count++];

    memset(n, 0, sizeof(Node));


    strncpy(
        n->id,
        id,
        MAX_ID - 1
    );

    n->id[MAX_ID - 1] = '\0';


    n->type = type;


    if (code != NULL) {

        strncpy(
            n->code,
            code,
            MAX_CODE - 1
        );

        n->code[MAX_CODE - 1] = '\0';
    }


    if (condition != NULL) {

        strncpy(
            n->condition,
            condition,
            MAX_COND - 1
        );

        n->condition[MAX_COND - 1] = '\0';
    }


    if (true_target != NULL) {

        strncpy(
            n->true_target,
            true_target,
            MAX_ID - 1
        );

        n->true_target[MAX_ID - 1] = '\0';
    }


    if (false_target != NULL) {

        strncpy(
            n->false_target,
            false_target,
            MAX_ID - 1
        );

        n->false_target[MAX_ID - 1] = '\0';
    }
}


static void validate_targets(void)
{
    int i;

    for (i = 0; i < node_count; i++) {

        Node *n = &nodes[i];


        /* DECISION */

        if (n->type == NODE_DECISION) {

            if (n->true_target[0] != '\0' &&
                find_node(n->true_target) == NULL)
            {
                fprintf(
                    stderr,
                    "Error: GOTO target '%s' in DECISION '%s' is not defined\n",
                    n->true_target,
                    n->id
                );

                semantic_error = 1;
            }


            if (n->false_target[0] != '\0' &&
                find_node(n->false_target) == NULL)
            {
                fprintf(
                    stderr,
                    "Error: GOTO target '%s' in DECISION '%s' is not defined\n",
                    n->false_target,
                    n->id
                );

                semantic_error = 1;
            }
        }


        /* UNCONDDEC */

        else if (n->type == NODE_UNCOND) {

            if (find_node(n->true_target) == NULL) {

                fprintf(
                    stderr,
                    "Error: GOTO target '%s' in UNCONDDEC '%s' is not defined\n",
                    n->true_target,
                    n->id
                );

                semantic_error = 1;
            }
        }
    }
}



static void generate_c(void)
{
    int i;


    fprintf(
        outfp,
        "/* Auto-generated from Ciitp source */\n"
    );

    fprintf(
        outfp,
        "#include <stdio.h>\n\n"
    );


    fprintf(
        outfp,
        "int main(void)\n"
    );

    fprintf(
        outfp,
        "{\n"
    );


    for (i = 0; i < node_count; i++) {

        Node *n = &nodes[i];


       

        fprintf(
            outfp,
            "\n%s: ;\n",
            n->id
        );


        /* BLOCK */

        if (n->type == NODE_BLOCK) {

            if (n->code[0] != '\0') {

                fprintf(
                    outfp,
                    "%s",
                    n->code
                );
            }
        }


        /* DECISION */

        else if (n->type == NODE_DECISION) {

            fprintf(
                outfp,
                "if (%s)\n",
                n->condition
            );


            fprintf(
                outfp,
                "    goto %s;\n",
                n->true_target
            );


            

            if (n->false_target[0] != '\0') {

                fprintf(
                    outfp,
                    "else\n"
                );

                fprintf(
                    outfp,
                    "    goto %s;\n",
                    n->false_target
                );
            }
        }


        /* UNCONDDEC */

        else if (n->type == NODE_UNCOND) {

            fprintf(
                outfp,
                "goto %s;\n",
                n->true_target
            );
        }
    }


    fprintf(
        outfp,
        "\nreturn 0;\n"
    );

    fprintf(
        outfp,
        "}\n"
    );
}

%}


%union {
    char *strval;
}


%token SYSTEM
%token PROCESS
%token PROCESSDEF

%token START
%token END

%token BLOCK
%token DECISION
%token UNCONDDEC

%token GOTO
%token IF
%token THEN
%token ELSE

%token SEMI
%token COMMA

%token <strval> ID


%%


/* =========================================
   PROGRAM
   ========================================= */

program:
      SYSTEM ID SEMI
      PROCESS idlist SEMI
      processdef

      {
          free($2);
      }
    ;




idlist:
      ID
      {
          free($1);
      }

    | idlist COMMA ID
      {
          free($3);
      }
    ;




processdef:
      PROCESSDEF ID START

      {
          free($2);
      }

      body END

      {
          validate_targets();

          if (!semantic_error)
              generate_c();
      }
    ;



body:
      /* empty */

    | body statement
    ;




statement:
      block_stmt
    | decision_stmt
    | uncond_stmt
    ;




block_stmt:
      BLOCK ID START

      {
          enter_blockcode();
      }

      END

      {
          add_node(
              $2,
              NODE_BLOCK,
              last_ccode,
              NULL,
              NULL,
              NULL
          );

          free($2);
      }
    ;




decision_stmt:
      DECISION ID
      IF THEN
      GOTO ID
      else_part

      {
          add_node(
              $2,
              NODE_DECISION,
              NULL,
              last_cond,
              $6,
              current_else_target
          );


          free($2);
          free($6);


          if (current_else_target != NULL) {

              free(current_else_target);

              current_else_target = NULL;
          }
      }
    ;




else_part:
      /* empty */

      {
          current_else_target = NULL;
      }

    | ELSE GOTO ID

      {
          current_else_target = $3;
      }
    ;




uncond_stmt:
      UNCONDDEC ID GOTO ID

      {
          add_node(
              $2,
              NODE_UNCOND,
              NULL,
              NULL,
              $4,
              NULL
          );


          free($2);
          free($4);
      }
    ;


%%


void yyerror(const char *s)
{
    fprintf(
        stderr,
        "Parse error: %s\n",
        s
    );

    semantic_error = 1;
}