#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>

#define MAX_NODES 256
#define MAX_ID 128
#define MAX_CODE 8192
#define MAX_COND 1024

typedef enum {
    NODE_BLOCK,
    NODE_DECISION,
    NODE_UNCOND
} NodeType;

typedef struct {
    char id[MAX_ID];
    NodeType type;

    char code[MAX_CODE];
    char condition[MAX_COND];

    char true_target[MAX_ID];
    char false_target[MAX_ID];

} Node;

extern char last_ccode[MAX_CODE];
extern char last_cond[MAX_COND];

extern FILE *outfp;

extern int semantic_error;

void enter_blockcode(void);

int yyparse(void);
int yylex(void);

void yyerror(const char *s);

#endif